# ATM_Interface
An ATM interface or system in java language.
